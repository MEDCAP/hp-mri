import os
import numpy as np
import sys

class cparams:
    params = [dict(key = "-help", description = "help", units = "", value = "", multiplier = 1, modified = False)]
    # parameter name, description, units, value, multiplier, modified (T/F)
    def __init__(self, p):
        # check format of parameter list
        if(all "key" in params)
            self.params = p
        else:
            print('format error setting command line parameters')
    def process(self, argv):
        # set parameter values from command line
        if(argv[len(argv) - 1] == '-help'):
            self.printparams('help / default params')
            sys.exit()
        for iarg in range(0, len(argv) - 1):
            for ip in range(0, len(self.params)):
                if(argv[iarg] == self.params[ip][0] and \
                        self.params[ip][5] == False):
                    self.setparam(argv[iarg], \
                            type(self.params[ip][3])(argv[iarg + 1]), False)
    def getparam(self, p):
        for iparam in range(0, len(self.params)):
            if(p == self.params[iparam][0]):
                if(not type(self.params[iparam][3]) == str):
                    return(self.params[iparam][3] / self.params[iparam][4])
                return(self.params[iparam][3])
        return('')
    def setparam(self, p, x, usemult):
        for iparam in range(0, len(self.params)):
            if(p == self.params[iparam][0]):
                self.params[iparam][3] = x
                if(usemult):
                    self.params[iparam][3] *= self.params[iparam][4]
                self.params[iparam][5] = True
    def printparams(self, s):
        print(s + ':')
        for ip in range(0, len(self.params)):
            msgtxt = self.params[ip][0] + ' <' + self.params[ip][1] + ' (' + \
                  str(self.params[ip][3]) + self.params[ip][2] + ')>'
            if(self.params[ip][5]):
                msgtxt += ' *'
            print('    ' + msgtxt)
