import os
import numpy as np
import matplotlib.pyplot as plt
import mapvbvd
import mrd
from MRSdata import MRSdata

filename = "PYR_Pt21_10-15-2024.mrs"

if(filename[(len(filename) - 4):] == ".mrs"):
    # An MR Solutions file
    m = MRSdata()
    dirlist = os.listdir(filename)
    MRDlist = [i for i in dirlist if ".MRD" in i]
    print(MRDlist)
    if(len(MRDlist) == 1):
        m.mread3d(filename + "/" + MRDlist[0])
    else:
        print("bad MRS directory format")
    print(m.getTXpower())


# load raw datafiles, identify gas/dissolved excitation pattern, split into gas and dissolved
if(0):
    twixObj = mapvbvd.mapVBVD(dynrawfname)
    try:
        twixObj.image.flagRemoveOS = False        # needed to prevent downsampling
    except:
        twixObj = twixObj[1]
    twixObj.image.flagRemoveOS = False        # needed to prevent downsampling
    twixObj.image.squeeze = True
    dynraw = unsqueeze(twixObj.image.unsorted()).astype('complex64')[trajec.killpts:, :, :]
    # TTTTTTTTTTTTTTTTTTERRRIBLE KLUGE FOR NOWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWW
    #dynraw = np.expand_dims(dynraw[:, 0, :] + 1j * dynraw[:, 1, :], 1)
    # TTTTTTTTTTTTTTTTTTERRRIBLE KLUGE FOR NOWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWW
    self.npts = dynraw.shape[0]
    self.nch = dynraw.shape[1] # this is meant to normalize each channel to its noise amplitude, but it seems like they already are for some reason
    for ich in range(self.nch):
        std = np.std(np.real(dynraw[:, ich, :]))
        y, x = np.histogram(np.real(dynraw), range=(-3*std, 3*std), bins=int(np.prod(dynraw[:, ich, :].shape) / 1000))
        popt, pcov = curve_fit(gaussfit, x[:-1], y, p0=(np.max(y), std, 0.0))
        dynraw[:, ich, :] /= popt[1]
    # separate out initial spectrum acquisition
    numspec = 0
    rawspec = []
    try:
        numspec = int(twixObj.hdr.MeasYaps[('sWipMemBlock', 'alFree', '10')] * \
                twixObj.hdr.MeasYaps[('sWipMemBlock', 'alFree', '11')] + 0.1)
        # TEMP KLUGE BECAUSE OF 20 MAGIC COOKIE!!!!!!!!!!!!!
        numspec = int(numspec / 20 * trajec.nsmpperusimg / self.npts + .1)
        # END TEMP KLUGE
        rawspec = dynraw[:, :, :numspec]
        dynraw = dynraw[:, :, numspec:]
    except:
        print('sWipMemBlock not found, setting numspec = 0')
    # separate out gas and dissolved acquisitions based on pattern of signal intensities.
    # can be just gas, gas/dissolved or gas/dissolved/dissolved
    pat = np.abs(np.fft.fft(dynraw[0, 0, :])) # FFT tells you acq ordering
    if(max(pat[(int(len(pat) / 3) - 5):(int(len(pat) / 3) + 5)]) > pat[0] / 5):
        print('identified sampling pattern gas-dissolved-dissolved')
        self.setimg(imgtype.GPDYN, dynraw[:, :, 0:(3 * int(dynraw.shape[2] / 3)):3], 0)
        self.setimg(imgtype.DPDYN, dynraw[:, :, 1:(3 * int(dynraw.shape[2] / 3)):3] + \
               dynraw[:, :, 2:(3 * int(dynraw.shape[2] / 3)):3], 0)
        if(len(refrawfname) > 0):
            self.setimg(imgtype.GPREF, refraw[:, :, 0:(3 * int(refraw.shape[2] / 3)):3], 0)
            self.setimg(imgtype.DPREF, refraw[:, :, 1:(3 * int(refraw.shape[2] / 3)):3] + \
                    refraw[:, :, 2:(3 * int(refraw.shape[2] / 3)):3], 0)
        self.ilvperTR = 3
    elif(max(pat[(int(len(pat) / 2) - 5):(int(len(pat) / 2) + 5)]) > pat[0] / 3):
        print('identified sampling pattern gas-dissolved')
        self.setimg(imgtype.GPDYN, dynraw[:, :, 0:(2 * int(dynraw.shape[2] / 2)):2], 0)
        self.setimg(imgtype.DPDYN, dynraw[:, :, 1:(2 * int(dynraw.shape[2] / 2)):2], 0)
        if(len(refrawfname) > 0):
            self.setimg(imgtype.GPREF, refraw[:, :, 0:(2 * int(refraw.shape[2] / 2)):2], 0)
            self.setimg(imgtype.DPREF, refraw[:, :, 1:(2 * int(refraw.shape[2] / 2)):2], 0)
        self.ilvperTR = 2
    else:
        print('identified sampling pattern gas-only')
        self.setimg(imgtype.GPDYN, dynraw, 0)
        if(len(refrawfname) > 0):
            self.setimg(imgtype.GPREF, refraw, 0)
        self.ilvperTR = 1
    # rephase everything so that the beginning of the fids has zero phase
    for ich in range(self.nch):
        gasphase = np.mean(self.getimg(imgtype.GPDYN)[0:4, ich, :])
        gasrephase = np.conj(gasphase) / np.abs(gasphase)
        self.getimg(imgtype.GPDYN)[:, ich, :] *= gasrephase
        if(len(rawspec) > 0):
            rawspec[:, ich, :] *= gasrephase
        if(len(self.getimg(imgtype.DPDYN)) > 0):
            self.getimg(imgtype.DPDYN)[:, ich, :] *= gasrephase
        # force spectra and regular dissolved phase imaging interleaves to have the same phase
        if(len(rawspec) > 0 and len(self.getimg(imgtype.DPDYN)) > 0):
            specphase = np.mean(rawspec[0:4, ich, :])
            dissphase = np.mean(self.getimg(imgtype.DPDYN)[0:4, ich, :])
            rawspec[:, ich, :] *= np.conj(specphase) / np.abs(specphase) * dissphase / np.abs(dissphase)
    if(numspec > 0):
        for ich in range(self.nch):
            fids = rawspec[:, ich, :]
            # choose fids for which the average of the first 100 points is at least 2x 
            # greater than the avg of the last 100
            idx = []
            for ifid in range(numspec):
                fids[:, ifid] *= np.exp(-np.array(range(self.npts)) / 200)
                if(np.sum(np.abs(fids[:100, ifid]), axis=(0)) > \
                        np.sum(np.abs(fids[(self.npts - 100):, ifid]), axis=(0)) * 2):
                    idx.append(ifid)
            # if there are less than 5 spectra, forget it
            if(len(idx) > 5):
                # get summed spectrum to identify the peaks
                nTE = 15
                for iTE in range(nTE):
                    sspect = np.fft.fftshift(np.fft.fft(np.sum(fids[iTE:, :], axis = 1)))
                    sspect -= (np.mean(sspect[0:10]) + np.mean(sspect[(len(sspect) - 10):])) / 2
                    abssspect = np.abs(sspect)
                    if(iTE == 0):
                        # find the first 4 nonconnected maxima
                        maxlist = []
                        while(len(maxlist) < 4):
                            thismax = np.argmax(abssspect)
                            abssspect[thismax] = 0.0
                            if(not (abssspect[thismax - 1] == 0.0 or abssspect[thismax + 1] == 0.0)):
                                maxlist.append(thismax)
                        # pick the two that are closest to the center
                        while(len(maxlist) > 2):
                            maxlist.remove(maxlist[np.argmax((np.abs(np.array(maxlist) - 
                                    len(abssspect) / 2)).astype(int))])
                        x0 = np.concatenate((np.array(maxlist), np.abs(sspect[maxlist]), \
                                np.angle(sspect[maxlist]), np.array([1, 1])))
                    p, pcov = curve_fit(lorfit, np.array(range(len(sspect))), np.concatenate((np.real(sspect), \
                            np.imag(sspect))), p0 = x0, method='lm', maxfev=50000)
                    x0 = p.copy()
                    # arguments to lorfit are: t(x, f0, f1, a0, a1, ph0, ph1, w0, w1):
                    fitspect = lorfit(np.array(range(len(sspect))), p[0], p[1], p[2], p[3], p[4], p[5], p[6], p[7])
                    fitsspect = fitspect[0:int(len(fitspect) / 2 + 0.1)] + 1j * fitspect[int(len(fitspect) / 2 + 0.1):]
                    plt.plot(sspect+20000*iTE, 'k')
                    plt.plot(fitsspect+20000*iTE, 'r')
                    RBCparams = [p[1], p[3], p[5], p[7]]
                    TPparams = [p[0], p[2], p[4], p[6]]
                    if(p[1] < p[0]):
                        temp = RBCparams.copy()
                        RBCparams = TPparams
                        TPparams = temp
                    # this won't work for multiple coils yet
                    if(self.nch > 1):
                        barf
                    deltaph = RBCparams[2] - TPparams[2]
                    self.RBCTPratio.append(RBCparams[1] * RBCparams[3] / (TPparams[1] * TPparams[3]))
                    at = 1 / trajec.spectBW * len(sspect)
                    self.fRBC.append((RBCparams[0] - np.floor(len(sspect) / 2 + 0.1)) / at)
                    self.fTP.append((TPparams[0] - np.floor(len(sspect) / 2 + 0.1)) / at)
                    self.sspect.append(sspect)
                    self.sspectfit.append(fitsspect)
                    self.sspectfreq.append(np.fft.fftshift(np.linspace(0, (len(sspect) - 1) / at, len(sspect))))
                    self.RBCphase.append(RBCparams[2])
                    self.TPphase.append(TPparams[2])
                    self.TEphase.append(self.TE + iTE / trajec.spectBW)
            plt.show()
            plt.figure()
            pRBC = np.polyfit(self.TEphase, self.RBCphase, 1)
            plt.plot(self.TEphase, self.RBCphase)
            plt.plot(self.TEphase, np.polyval(pRBC, self.TEphase))
            pTP = np.polyfit(self.TEphase, self.TPphase, 1)
            plt.plot(self.TEphase, self.TPphase)
            plt.plot(self.TEphase, np.polyval(pTP, self.TEphase))
            plt.plot(self.TEphase, self.RBCTPratio)
            plt.show()
            self.deltaphase = pRBC[1] - pTP[1]
            self.TEeff = self.deltaphase / (self.fRBC[0] - self.fTP[0]) / 2 / np.pi - \
                    trajec.killpts / trajec.spectBW + trajec.killpts / trajec.BW
            self.TEeff2 = -(pRBC[1] - pTP[1]) / (pTP[0] - pRBC[0]) - \
                    trajec.killpts / trajec.spectBW + trajec.killpts / trajec.BW
    # figure out time of the first imaging interleave
    self.TR = twixObj.hdr.MeasYaps[('alTR', '0')] * 1.0E-6 # s
    self.TE = twixObj.hdr.MeasYaps[('alTE', '0')] * 1.0E-6 # s
    self.DPoff = twixObj.hdr.MeasYaps[('sWipMemBlock', 'adFree', '2')]
    if(np.fabs(self.TR - 0.0223) < 1E-6):
        self.TR = 22.26E-3 ### KLUGE FOR NOW, IT ROUNDS IN THE FILE!
    dtdyn = twixObj.hdr.MeasYaps[('sRXSPEC', 'alDwellTime', '0')] * 1.0E-9 # s
    try:
        dtdyn = twixObj.hdr.MeasYaps[('sRXSPEC', 'alDwellTime', '1')] * 1.0E-9
    except:
        dtdyn = dtdyn
    extratime = self.TR / self.ilvperTR - dtdyn * self.npts
    extratime = 2.191E-3  ### KLUGE FOR NOW
    if(numspec > 0):
        dtspec = twixObj.hdr.MeasYaps[('sWipMemBlock', 'alFree', '12')] * 1.0E-6 # s
        TRspec = (extratime + self.npts * dtspec)
        firstilvtime = numspec * TRspec
