import os
import sys
import time
import numpy as np
import matplotlib.pyplot as plt
import mapvbvd
sys.path.insert(0, '../../mrd-fork/python')
import mrd
from enum import IntEnum
from cparams import cparams

# list of possible requests
    params = [dict(key = "-help", description = "help", units = "", value = "", multiplier = 1, modified = False)]
cp = cparams( [ \
    dict(key = "-p", description = "pulse", units = "V", t0 = 0, t1 = 0xFFFFFFFFFFFFFFFF, dt = -1), \
    dict(key = "-g", description = "gradients", units = "T/m", t0 = 0, t1 = 0xFFFFFFFFFFFFFFFF, dt = -1]], \
    dict(key = "-d", description = "raw data", units = "V", t0 = 0, t1 = 0xFFFFFFFFFFFFFFFF, dt = -1]], \
    dict(key = "-ph", description = "CO phase", units = "rad", t0 = 0, t1 = 0xFFFFFFFFFFFFFFFF, dt = -1]], \
    dict(key = "-i", description = "image list", value = [], dt = -1]
cp.process(sys.argv)

import subprocess

result = subprocess.run(['ping', 'google.com', '-n', '2'], capture_output=True, text=True)

c = 0
while True:
    print(c, "Output:")
    print(result.stdout)
    time.sleep(.1)
    c += 1
sys.exit(1)

fifo_path = "/tmp/my_fifo"
if not os.path.exists(fifo_path):
    os.mkfifo(fifo_path)
with open(fifo_path, "r") as fifo:
    while True:
        message = fifo.readline().strip()
        if message:
            print("Received:", message)

gamma = 11.7767338 # MHz/T


class acquisition_type(IntEnum):
    AT_SPECTRUM = 0
    AT_GAS = 1
    AT_DISSOLVED = 2

# load pulse shape
kaipulse = np.loadtxt('kaipulse')
def calcB1(t, pulse_len):
    pulsedt = pulse_len / len(kaipulse)
    pulsetimestep = int(t / pulsedt)
    fpulsetimestep = (t - pulsetimestep * pulsedt) / pulsedt
    x = kaipulse[pulsetimestep] * (1 - fpulsetimestep) + kaipulse[pulsetimestep + 1] * fpulsetimestep
    return(x)

# load trajectory
nilvperusimg = 26
nusimg = 32
nuniqueilv = nilvperusimg * nusimg
if(os.path.exists(cp.getparam('-tj'))):
    traj = np.load(cp.getparam('-tj'))
else:
    print('trajectory file not found')
    sys.exit(1)

# load Siemens raw data file
try:
    twixObj = mapvbvd.mapVBVD(cp.getparam('-rd'))
except:
    print('bad target file ' + cp.getparam('-rd'))
    sys.exit(1)

# test format, sometimes it's an array. If so, set object to 1st element
try:
    twixObj.image.flagRemoveOS = False        # needed to prevent downsampling
except:
    twixObj = twixObj[1]
#print(twixObj.hdr.MeasYaps)
twixObj.image.flagRemoveOS = False        # needed to prevent downsampling
twixObj.image.squeeze = True
rawdata = twixObj.image.unsorted().astype('complex64')
if(len(rawdata.shape) == 2):
    rawdatacopy = np.zeros((rawdata.shape[0], 1, rawdata.shape[1]), dtype = 'complex').astype('complex64')
    rawdatacopy[:, 0, :] = rawdata
    rawdata = rawdatacopy
npts = rawdata.shape[0]
nch = rawdata.shape[1]
nacq = rawdata.shape[2]
gp_freq = 0
dp_freq = twixObj.hdr.MeasYaps[('sWipMemBlock', 'adFree', '2')] * gamma
pulse_len = twixObj.hdr.MeasYaps[('sWipMemBlock', 'adFree', '4')] * 1.0E-3
    
nuniquesmp = traj.shape[0]
nsmpperusimg = int(nuniquesmp / nusimg + 0.1)
numspec = 0
try:
    numspec = int(twixObj.hdr.MeasYaps[('sWipMemBlock', 'alFree', '10')] * \
            twixObj.hdr.MeasYaps[('sWipMemBlock', 'alFree', '11')] + 0.1)
    ## TEMP KLUGE BECAUSE OF 20 MAGIC COOKIE
    numspec = int(numspec / 20 * nsmpperusimg / npts + 0.1)
except:
    print("sWipMemBlock not found, setting numspec = 0")
samplingtype = np.zeros(nacq, dtype = acquisition_type)
samplingtype[:numspec] = acquisition_type.AT_SPECTRUM
# separate out gas and dissolved acquisitions based on pattern of signal intensities.
# can be just gas, gas/dissolved, or gas/dissolved/dissolved
pat = np.abs(np.fft.fft(rawdata[0, 0, :])) # FFT tells you ordering
if(max(pat[(int(len(pat) / 3) - 5):(int(len(pat) / 3) + 5)]) > pat[0] / 5):
    samplingtype[numspec:] = acquisition_type.AT_DISSOLVED
    samplingtype[numspec::3] = acquisition_type.AT_GAS
    ilvperTR = 3
elif(max(pat[(int(len(pat) / 2) - 5):(int(len(pat) / 2) + 5)]) > pat[0] / 3):
    samplingtype[numspec::2] = acquisition_type.AT_GAS
    samplingtype[(numspec+1)::2] = acquisition_type.AT_DISSOLVED
    ilvperTR = 2
else:
    samplingtype[numspec:] = acquisition_type.AT_GAS
    ilvperTR = 1

TR = twixObj.hdr.MeasYaps[('alTR', '0')] * 1.0E-6
if(np.fabs(TR - 0.0223) < 1E-6):
    TR = 22.26E-3
TE = twixObj.hdr.MeasYaps[('alTE', '0')] * 1.0E-6
DPoff = twixObj.hdr.MeasYaps[('sWipMemBlock', 'adFree', '2')]
dtdyn = twixObj.hdr.MeasYaps[('sRXSPEC', 'alDwellTime', '0')] * 1.0E-9
try:
    dtdyn = twixObj.hdr.MeasYaps[('sRXSPEC', 'alDwellTime', '1')] * 1.0E-9
except:
    dtdyn = dtdyn
extratime = TR / ilvperTR - dtdyn * npts
extratime = 2.191E-3  ### KLUGE FOR NOW
firstilvtime = 0.0
if(numspec > 0):
    dtspec = twixObj.hdr.MeasYaps[('sWipMemBlock', 'alFree', '12')] * 1.0E-6 # s
    TRspec = (extratime + npts * dtspec)
    firstilvtime = numspec * TRspec

def generate_acquisition():
    for iacq in range(nacq):
        print(iacq)
        if(iacq == 0):
             CO_phase = 0.0
        # make the pulse
        p = mrd.Pulse()
        CO_freq = dp_freq
        if(iacq < numspec):
            pulse_start = TRspec * iacq
        else:
            pulse_start = TRspec * numspec + (iacq - numspec) * TR / ilvperTR
            if(((iacq - numspec) % ilvperTR) == 0):
                CO_freq = gp_freq
        pulse_end = pulse_start + pulse_len
        p.head.time_stamp_ns = int(pulse_start * 1.0E+9)
        p.head.sample_time_ns = 10000
        pulsedt = 10.0E-6
        npulsepoints = int(pulse_len / pulsedt)
        p.amplitude = np.zeros((1, npulsepoints)).astype(np.float32)
        p.phase = np.zeros(npulsepoints).astype(np.float32)
        for idt in range(npulsepoints):
            p.amplitude[0, idt] = calcB1(idt * pulsedt, pulse_len).astype(np.float32)
            p.phase[idt] = CO_phase
            CO_phase += CO_freq * pulsedt
            if(CO_phase > np.pi):
                CO_phase -= 2.0 * np.pi
        yield mrd.StreamItem.Pulse(p)
        if(iacq > numspec):
            ilvidx = (iacq - numspec) % nuniqueilv
            # make the gradients
            g = mrd.Gradient()
            g.head.gradient_time_stamp_ns = int((pulse_start + TE) * 1.0E+9)
            g.head.gradient_sample_time_ns = 10000 # 10us
            g.rl = traj[(ilvidx * npts):((ilvidx + 1) * npts), 0].astype(np.float32)
            g.rl[:-1] -= g.rl[1:]
            g.rl[-1] = g.rl[-2]
            g.ap = traj[(ilvidx * npts):((ilvidx + 1) * npts), 1].astype(np.float32)
            g.ap[:-1] -= g.ap[1:]
            g.ap[-1] = g.ap[-2]
            g.fh = traj[(ilvidx * npts):((ilvidx + 1) * npts), 2].astype(np.float32)
            g.fh[:-1] -= g.fh[1:]
            g.fh[-1] = g.fh[-2]
            yield mrd.StreamItem.Gradient(g)
        # make the acquisition
        a = mrd.Acquisition()
        if(iacq == 0 or iacq == numspec):
            a.head.flags = mrd.AcquisitionFlags.FIRST_IN_SET
        if(iacq == numspec - 1 or iacq == nacq - 1):
            a.head.flags = mrd.AcquisitionFlags.LAST_IN_SET
        a.data = rawdata[:, :, iacq]
        a.head.acquisition_time_stamp_ns = int((pulse_start + TE) * 1.0E+9)
        a.head.sample_time_ns = 10000
        a.phase = np.array(range(npts)).astype(np.float32) * 10.0E-6 * CO_freq + CO_phase
        CO_phase += npts * 10.0E-6 * CO_freq
        yield mrd.StreamItem.Acquisition(a)

with mrd.BinaryMrdWriter(cp.getparam('-o')) as w:
    # make and write output file header
    h = mrd.Header()
    w.write_header(h)
    w.write_data(generate_acquisition())

if(0):
    # figure out time of the first imaging interleave
    self.TE = twixObj.hdr.MeasYaps[('alTE', '0')] * 1.0E-6 # s
    self.DPoff = twixObj.hdr.MeasYaps[('sWipMemBlock', 'adFree', '2')]
    dtdyn = twixObj.hdr.MeasYaps[('sRXSPEC', 'alDwellTime', '0')] * 1.0E-9 # s
    try:
        dtdyn = twixObj.hdr.MeasYaps[('sRXSPEC', 'alDwellTime', '1')] * 1.0E-9
    except:
        dtdyn = dtdyn
