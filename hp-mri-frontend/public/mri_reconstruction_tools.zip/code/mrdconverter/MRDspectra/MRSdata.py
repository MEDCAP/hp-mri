#%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
#% PJD, MR Solutions, last modified 15/9/2017
#% Translated to python by Steve Kadlecek, 10/17/2023
#%
#% .mrd file readear for multislice int or float type data. Stores the data
#% in a structure with information on the size of the data set, etc. 
#% 'name' is a string containing the path and filename of the .mrd file.
#% If 'expt_to_show' is present, its value replaces the number of 
#% experiments read from the data file. This sllightly crud method enables 
#% partial data files to be opened for multi-experiment data sets.
#%
#% [data] = mread(name, expt_to_show)
#% 
#% Added file footer reader - opens ASCII parameter list, adds it to the 
#% ouput as a string.
#%
#% Added handling of 'no_echoes' in 'thirddim'.
#%
#% Completely rewritten to run considerably faster, and to replace original
#% ad hoc structure. For 256 x 128 x 24 data, this version runs in ~0.1s,
#% rather than ~1/3s for the old version.
#%
#% Added ability to handle real only data - now opens .sur files correctly.
#%
#% The header is arguably redundant. Maintained for now in case other 
#% fields are ever used in the header...
#%
#%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

import numpy as np
import matplotlib.pyplot as plt
import os


class MRSdata:
    def __init__(self):
        self.samples = 0
        self.views = 0
        self.sliceviews = 0
        self.slices = 0
        self.echoes = 0
        self.nex = 0
    def mread3d(self, datapath):
        fd = open(datapath, 'rb')
        fdbytes = fd.read()
        print(fdbytes.type())
        barf
        self.samples = np.frombuffer(fdbytes[0:4], dtype = 'int32')[0]
        self.views = np.frombuffer(fdbytes[4:8], dtype = 'int32')[0]
        self.sliceviews = np.frombuffer(fdbytes[8:12], dtype = 'int32')[0]
        self.slices = np.frombuffer(fdbytes[12:16], dtype = 'int32')[0]
        self.type = np.frombuffer(fdbytes[18:20], dtype = 'int16')[0] 
        self.echoes = np.frombuffer(fdbytes[152:156], dtype = 'int32')[0]
        self.nex = np.frombuffer(fdbytes[156:160], dtype = 'int32')[0]
        print(self.type, self.samples, self.views, self.sliceviews, self.slices, self.echoes, self.nex)
        totalpts = self.samples * self.views * self.sliceviews * self.slices * self.echoes * self.nex
        dstart = 512
        if self.type == 3:
            dend = dstart + totalpts * 2
            rawdata = np.frombuffer(fdbytes[dstart:dend], dtype = 'int16')
        elif self.type == 16:
            dend = dstart + totalpts * 2
            d = np.frombuffer(fdbytes[dstart:dend], dtype = 'uint8')
            rawdata = d[::2] + 1j * d[1::2]
        elif self.type == 17:
            dend = dstart + totalpts * 2
            d = np.frombuffer(fdbytes[dstart:dend], dtype = 'int8')
            rawdata = d[::2] + 1j * d[1::2]
        elif self.type == 18 or self.type == 19:
            dend = dstart + totalpts * 4
            d = np.frombuffer(fdbytes[dstart:dend], dtype = 'int16')
            rawdata = d[::2] + 1j * d[1::2]
        elif self.type == 20:
            dend = dstart + totalpts * 8
            rawdata = d[::2] + 1j * d[1::2]
            d = np.frombuffer(fdbytes[dstart:dend], dtype = 'int32')
        elif self.type == 21:
            dend = dstart + totalpts * 8
            d = np.frombuffer(fdbytes[dstart:dend], dtype = 'float32')
            rawdata = d[::2] + 1j * d[1::2]
        elif self.type == 22:
            dend = dstart + totalpts * 16
            d = np.frombuffer(fdbytes[dstart:dend], dtype = 'float64')
            rawdata = d[::2] + 1j * d[1::2]
        else:
            print('unknown data format')
            return
        self.parameters = fdbytes[dend:].astype('str') # parameters is the text part that describes settings, appended to the end of the file
        self.rawdata = np.reshape(rawdata, (self.samples, self.views, \
                self.sliceviews, self.slices, self.echoes, self.nex), order = 'F')
    def getTXpower(self): return(self.parameters.split("_ObserveTransmitGain", 1)[1].split("\r", 1)[0])
