% Copyright (c) Microsoft Corporation.
% Licensed under the MIT License.

classdef SizeSerializer < yardl.binary.Uint64Serializer
end
