% Copyright (c) Microsoft Corporation.
% Licensed under the MIT License.

function res = MAGIC_BYTES
    res = unicode2native('yardl');
end
