% Copyright (c) Microsoft Corporation.
% Licensed under the MIT License.

function res = CURRENT_BINARY_FORMAT_VERSION
    res = int32(1);
end
