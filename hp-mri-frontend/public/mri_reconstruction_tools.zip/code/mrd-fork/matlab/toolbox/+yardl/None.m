% Copyright (c) Microsoft Corporation.
% Licensed under the MIT License.

function n = None()
    n = yardl.Optional();
end
