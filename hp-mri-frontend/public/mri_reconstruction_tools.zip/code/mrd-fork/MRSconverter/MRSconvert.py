import numpy as np
import matplotlib.pyplot as plt
import os
#from scipy.interpolate import RBFInterpolator


class MRSdata:
    def __init__(self):
        self.samples = 0
        self.views = 0
        self.sliceviews = 0
        self.slices = 0
        self.echoes = 0
        self.nex = 0
    def mread3d(self, datapath):
        fd = open(datapath, 'rb')
        fdbytes = fd.read()
        self.samples = np.frombuffer(fdbytes[0:4], dtype = 'int32')[0]
        self.views = np.frombuffer(fdbytes[4:8], dtype = 'int32')[0]
        self.sliceviews = np.frombuffer(fdbytes[8:12], dtype = 'int32')[0]
        self.slices = np.frombuffer(fdbytes[12:16], dtype = 'int32')[0]
        self.type = np.frombuffer(fdbytes[18:20], dtype = 'int16')[0] 
        self.echoes = np.frombuffer(fdbytes[152:156], dtype = 'int32')[0]
        self.nex = np.frombuffer(fdbytes[156:160], dtype = 'int32')[0]
        #print(self.type, self.samples, self.views, self.sliceviews, self.slices, self.echoes, self.nex)
        totalpts = self.samples * self.views * self.sliceviews * self.slices * self.echoes * self.nex
        dstart = 512
        if self.type == 3:
            dend = dstart + totalpts * 2
            rawdata = np.frombuffer(fdbytes[dstart:dend], dtype = 'int16')
        elif self.type == 16:
            dend = dstart + totalpts * 2
            d = np.frombuffer(fdbytes[dstart:dend], dtype = 'uint8')
            rawdata = d[::2] + 1j * d[1::2]
        elif self.type == 17:
            dend = dstart + totalpts * 2
            d = np.frombuffer(fdbytes[dstart:dend], dtype = 'int8')
            rawdata = d[::2] + 1j * d[1::2]
        elif self.type == 18 or self.type == 19:
            dend = dstart + totalpts * 4
            d = np.frombuffer(fdbytes[dstart:dend], dtype = 'int16')
            rawdata = d[::2] + 1j * d[1::2]
        elif self.type == 20:
            dend = dstart + totalpts * 8
            rawdata = d[::2] + 1j * d[1::2]
            d = np.frombuffer(fdbytes[dstart:dend], dtype = 'int32')
        elif self.type == 21:
            dend = dstart + totalpts * 8
            d = np.frombuffer(fdbytes[dstart:dend], dtype = 'float32')
            rawdata = d[::2] + 1j * d[1::2]
        elif self.type == 22:
            dend = dstart + totalpts * 16
            d = np.frombuffer(fdbytes[dstart:dend], dtype = 'float64')
            rawdata = d[::2] + 1j * d[1::2]
        else:
            print('unknown data format')
            return
        self.parameters = fdbytes[dend:] # parameters is the text part that describes settings, appended to the end of the file
        print(self.parameters)
        self.rawdata = np.reshape(rawdata, (self.samples, self.views, self.sliceviews, self.slices, self.echoes, self.nex), order = 'F')
#% data comes out as:
#%   dim1 = samples
#%   dim2 = views
#%   dim3 = sliceviews
#%   dim4 = slices
#%   dim5 = echoes
#%   dim6 = experiments

import re
import codecs
g = MRSdata()
g.mread3d("ischemia_59_1/epsi/12547/12547_000_0.MRD")
splitparam = g.parameters.split(b'\n')
for ip in range(len(splitparam)):
    print(splitparam[ip])
barf
#g.mread3d("ischemia_59_1/epsi/12548/12548_000_0.MRD")
BW = 40000
TE = 0.0000
npeacq = 12
npegrid = 12
nroacq = 20
nrogrid = 12
nechoacq = 64
nechogrid = 64
#krofly = np.array([-5,-4,-3,-2,-1,0,1,2,3,4,4+15/16,5+7/16,5+5/16,3+13/16,1,-2,-4-13/16,-6-5/16,-6-7/16,-5-15/16]) + 5
krofly = np.array([-6-5/16,-6-7/16,-5-15/16,-5,-4,-3,-2,-1,0,1,2,3,4,4+15/16,5+7/16,5+5/16,3+13/16,1,-2,-4-13/16]) + 6

flatraw = np.ndarray.flatten(g.rawdata[:,:,0,0,0,0], order='f')
kpe = np.zeros(len(flatraw))
kro = np.zeros(len(flatraw))
kt = np.zeros(len(flatraw))
minkpe = 1E+6
maxkpe = -1E+6
minkro = 1E+6
maxkro = -1E+6
minkt = 0
maxkt = -1E+6
for j in range(0, len(flatraw)):
    kpe[j] = int(j / len(flatraw) * npeacq)
    kt[j] = (j - kpe[j] * nroacq * nechoacq) / BW + TE
    kro[j] = krofly[j % nroacq]
    minkpe = min(minkpe, kpe[j])
    minkro = min(minkro, kro[j])
    minkt = min(minkt, kt[j])
    maxkpe = max(maxkpe, kpe[j])
    maxkro = max(maxkro, kro[j])
    maxkt = max(maxkt, kt[j])
plt.plot(kt, np.abs(flatraw))
plt.plot(kt, 1*kro)
plt.show()

k = np.zeros((npegrid,nrogrid,nechogrid), dtype='complex')
kcpe = np.linspace(minkpe, maxkpe, k.shape[0])
kcro = np.linspace(minkro, maxkro, k.shape[1])
kct = np.linspace(minkt, maxkt, k.shape[2]) 
kn = np.zeros((npegrid,nrogrid,nechogrid)) + 1.0E-10
wpe = .1
wro = .1
wt = .05 * nechoacq / BW
bxszpe = 1
bxszro = 1
bxszt = 2
lb = 1000

for j in range(0, len(flatraw)):
    cidxpe = np.argmin(np.abs(kpe[j] - kcpe))
    cidxro = np.argmin(np.abs(kro[j] - kcro))
    cidxt = np.argmin(np.abs(kt[j] - kct))
    for jpe in range(max(cidxpe - bxszpe, 0), min(cidxpe + bxszpe + 1, np.shape(k)[0])):
        for jro in range(max(cidxro - bxszro, 0), min(cidxro + bxszro + 1, np.shape(k)[1])):
            for jt in range(max(cidxt - bxszt, 0), min(cidxt + bxszt + 1, np.shape(k)[2])):
                w = np.exp(-(kpe[j] - kcpe[jpe])**2 / wpe**2 - (kro[j] - kcro[jro])**2 / wro**2 - \
                        (kt[j] - kct[jt])**2 / wt**2)
#                print(j, jt, kt[j], kct[jt], w)
                k[jpe, jro, jt] += flatraw[j] * w * np.exp(-kt[j] / lb)
                kn[jpe, jro, jt] += w
k /= kn
plt.subplot(1,2,1)
plt.imshow(np.abs(k[:,5,:]))

kref = k.copy()*0
kref = np.zeros((12, 12, 64), dtype='complex')
for ipe in range(12):
    for iro in range(12):
        kref[ipe, iro, :] = g.rawdata[(iro+0)::20, ipe, 0, 0, 0, 0]
plt.subplot(1,2,2)
plt.imshow(np.abs(kref[:,5,:]))
plt.show()

img = np.fft.fftshift(np.fft.fftn(np.fft.ifftshift(k, axes=(0,1))), axes=(0,1,2))
imgref = np.fft.fftshift(np.fft.fftn(np.fft.ifftshift(kref, axes=(0,1))), axes=(0,1,2))
imgmax = np.max(np.abs(img))
imgrefmax = np.max(np.abs(imgref))
for ipe in range(img.shape[0]):
    longspect = np.zeros(img.shape[1] * img.shape[2])
    longspectref = np.zeros(imgref.shape[1] * imgref.shape[2])
    for iro in range(img.shape[1]):
        longspect[(iro * img.shape[2]):((iro + 1) * img.shape[2])] = np.abs(np.exp(1j*1.5)*img[ipe, iro, :])
        longspectref[(iro * imgref.shape[2]):((iro + 1) * imgref.shape[2])] = np.abs(np.exp(1j*1.5)*imgref[ipe, iro, :])
    plt.plot(np.array(range(len(longspect)))/len(longspect), longspect + ipe * imgmax, 'r')
    plt.plot(np.array(range(len(longspectref)))/len(longspectref), longspectref + ipe * imgmax, 'b')
for iro in range(img.shape[1]):
    plt.plot([iro / img.shape[1], iro / img.shape[1]], [0, img.shape[0] * imgmax], 'k')
plt.show()
