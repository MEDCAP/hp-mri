# Documentation Website

This site uses [VitePress](https://vitepress.dev/) to generate a static site for documentation. To run it locally, run

```bash
$ just start-docs-website
```

In most cases, the page in the browser should update when saving the markdown files. But changes to `.vitepress/config.mts` require a page reload.
