Library and tools for working with data in the ISMRM Raw Data (MRD) format.
