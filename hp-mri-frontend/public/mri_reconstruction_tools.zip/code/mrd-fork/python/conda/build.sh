#!/bin/bash

set -euo pipefail

pip install --no-deps .
