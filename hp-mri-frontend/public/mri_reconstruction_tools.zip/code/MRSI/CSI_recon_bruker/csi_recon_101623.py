import numpy as np
import matplotlib.pyplot as plt

# index order for gx and gy
centricgrad = [4, 3, 5, 2, 6, 1, 7, 0]

# load the stream of int32's in acquisition order
raw = np.fromfile('rawdata 1.job0', dtype = np.int32)
plt.plot(raw)
plt.show()

# change to real + i * imag
raw = raw[0::2] + 1j * raw[1::2]

# number of points in the acquisition should be total acquired number of points / matrix size
npts = int(len(raw) / len(centricgrad)**2 + .01) 
print(npts)

# now put into k space matrix
kspace = np.zeros((len(centricgrad), len(centricgrad), npts), dtype = 'complex')
cnt = 0
for ix in range(0, len(centricgrad)):
    for iy in range(0, len(centricgrad)):
        kspace[centricgrad[ix], centricgrad[iy], :] = raw[(cnt * npts):((cnt + 1) * npts)]
        cnt += 1

# 3d fft, abs and scale to max of 1
rspace = np.abs(np.fft.fftshift(np.fft.fftn(kspace, axes=(0, 1, 2))))
rspace /= np.max(rspace)

# plot
for ix in range(0, len(centricgrad)):
    for iy in range(0, len(centricgrad)):
        plt.plot(np.array(range((ix * npts), ((ix + 1) * npts))) + ix * int(npts / 10), rspace[ix, iy, :] + iy, 'k')
plt.show()
