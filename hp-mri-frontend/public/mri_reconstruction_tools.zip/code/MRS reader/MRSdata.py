#%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
#% PJD, MR Solutions, last modified 15/9/2017
#% Translated to python by Steve Kadlecek, 10/17/2023
#%
#% .mrd file readear for multislice int or float type data. Stores the data
#% in a structure with information on the size of the data set, etc. 
#% 'name' is a string containing the path and filename of the .mrd file.
#% If 'expt_to_show' is present, its value replaces the number of 
#% experiments read from the data file. This sllightly crud method enables 
#% partial data files to be opened for multi-experiment data sets.
#%
#% [data] = mread(name, expt_to_show)
#% 
#% Added file footer reader - opens ASCII parameter list, adds it to the 
#% ouput as a string.
#%
#% Added handling of 'no_echoes' in 'thirddim'.
#%
#% Completely rewritten to run considerably faster, and to replace original
#% ad hoc structure. For 256 x 128 x 24 data, this version runs in ~0.1s,
#% rather than ~1/3s for the old version.
#%
#% Added ability to handle real only data - now opens .sur files correctly.
#%
#% The header is arguably redundant. Maintained for now in case other 
#% fields are ever used in the header...
#%
#%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

import numpy as np
import matplotlib.pyplot as plt
import os


class MRSdata:
    def __init__(self):
        self.samples = 0
        self.views = 0
        self.sliceviews = 0
        self.slices = 0
        self.echoes = 0
        self.nex = 0
    def mread3d(self, datapath):
        fd = open(datapath, 'rb')
        fdbytes = fd.read()
        self.samples = np.frombuffer(fdbytes[0:4], dtype = 'int32')[0]
        self.views = np.frombuffer(fdbytes[4:8], dtype = 'int32')[0]
        self.sliceviews = np.frombuffer(fdbytes[8:12], dtype = 'int32')[0]
        self.slices = np.frombuffer(fdbytes[12:16], dtype = 'int32')[0]
        self.type = np.frombuffer(fdbytes[18:20], dtype = 'int16')[0] 
        self.echoes = np.frombuffer(fdbytes[152:156], dtype = 'int32')[0]
        self.nex = np.frombuffer(fdbytes[156:160], dtype = 'int32')[0]
        print(self.type, self.samples, self.views, self.sliceviews, self.slices, self.echoes, self.nex)
        totalpts = self.samples * self.views * self.sliceviews * self.slices * self.echoes * self.nex
        dstart = 512
        if self.type == 3:
            dend = dstart + totalpts * 2
            rawdata = np.frombuffer(fdbytes[dstart:dend], dtype = 'int16')
        elif self.type == 16:
            dend = dstart + totalpts * 2
            d = np.frombuffer(fdbytes[dstart:dend], dtype = 'uint8')
            rawdata = d[::2] + 1j * d[1::2]
        elif self.type == 17:
            dend = dstart + totalpts * 2
            d = np.frombuffer(fdbytes[dstart:dend], dtype = 'int8')
            rawdata = d[::2] + 1j * d[1::2]
        elif self.type == 18 or self.type == 19:
            dend = dstart + totalpts * 4
            d = np.frombuffer(fdbytes[dstart:dend], dtype = 'int16')
            rawdata = d[::2] + 1j * d[1::2]
        elif self.type == 20:
            dend = dstart + totalpts * 8
            rawdata = d[::2] + 1j * d[1::2]
            d = np.frombuffer(fdbytes[dstart:dend], dtype = 'int32')
        elif self.type == 21:
            dend = dstart + totalpts * 8
            d = np.frombuffer(fdbytes[dstart:dend], dtype = 'float32')
            rawdata = d[::2] + 1j * d[1::2]
        elif self.type == 22:
            dend = dstart + totalpts * 16
            d = np.frombuffer(fdbytes[dstart:dend], dtype = 'float64')
            rawdata = d[::2] + 1j * d[1::2]
        else:
            print('unknown data format')
            return
        self.parameters = fdbytes[dend:] # parameters is the text part that describes settings, appended to the end of the file
        print(self.parameters)
        self.rawdata = np.reshape(rawdata, (self.samples, self.views, self.sliceviews, self.slices, self.echoes, self.nex), order = 'F')
g = MRSdata()
g.mread3d("13817_000_0.MRD")
x = g.rawdata[:,0,0,0,0,:]
gfid = np.zeros((1024),dtype='complex')
y = np.array(range(1024)) * 10000/1024/74.95
a=np.zeros(80)
for j in range(0, 80):
    thisfid = x[:,j]
    gfid += thisfid
    thisfid *= np.exp(-np.array(range(0,1024))/100)
    thisspect = np.fft.fftshift(np.fft.fft(thisfid) * np.exp(1j*5.4))
    a[j] = np.sum(np.real(thisspect[490:500]))
gspect = np.fft.fftshift(np.fft.fft(gfid) * np.exp(1j*5.4))
plt.plot(np.real(gspect))
plt.show()
plt.plot(a)
plt.show()

#% data comes out as:
#%   dim1 = samples
#%   dim2 = views
#%   dim3 = sliceviews
#%   dim4 = slices
#%   dim5 = echoes
#%   dim6 = experiments


#%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
#% The mrd structure format:
#%
#% (name).path		The .mrd file path as a string
#% 
#% (name).samples	The number of samples per view
#% 
#% (name).views		The number of view lines per slice
#% 
#% (name).sliceviews	The number of views in the slice direction for 3D acquisition
#% 
#% (name).slices		The number of slices
#% 
#% (name).type		19 for complex ints (16 bit values),
#%                   21 for complex floats (32 bit values)
#% 
#% (name).echoes		The number of echoes per shot
#% 
#% (name).nex		The number of experiments in the file
#%
#% (name).thirddim   The number of experiements multiplied by the number of
#%                   slices multiplied by the number of sliceviews.
#% 
#% (name).header		The header containing the above information read in as
#%                   int16 type - i.e. wrongly. Maintained to allow writing 
#%                   to a properly formatted .mrd file from the Matlab 
#%                   structure.
#% 
#% (name).parameters	The parameter file as a string
#% 
#% (name).data		The actual data
#%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
